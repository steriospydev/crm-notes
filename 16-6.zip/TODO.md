## FRONTEND

## BACKEND
- Add User Dashboard Pages
- Add Customer views
- Add User Roles(ALL) 
- IMPLEMENT: ALARM SYSTEM USER
- IMPLEMENT: Connect notes with each other


# COMPLETED
- Fix UI/UX login page DONE
- Fix footer DONE
- Make subject choice DONE
- FIlter data DONE
- Search data DONE 
- Add note identifier DONE
- Add NoteManager for filtering and search DONE
- Create ClientCreateForm (2F) Done
- remove "Ολοκληρωθηκε" from note.status(2F) DONE
- Add create client form in modal(4B), (6B) DONE
## Dummy Data 



